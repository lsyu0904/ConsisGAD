"""Sparse optimizer is not supported for mxnet"""
