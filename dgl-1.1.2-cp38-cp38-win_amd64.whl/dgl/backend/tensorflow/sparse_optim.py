"""Sparse optimizer is not supported for tensorflow"""
