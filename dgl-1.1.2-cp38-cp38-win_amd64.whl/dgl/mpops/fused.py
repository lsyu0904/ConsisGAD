"""Operators that fuse the computation and aggregation of edge data."""
